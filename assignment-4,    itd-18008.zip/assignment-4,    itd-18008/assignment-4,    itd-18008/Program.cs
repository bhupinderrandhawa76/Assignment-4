﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3BhupinderjeetSinghP1
{
    class Program
    {
        static void Main(string[] args)
        {

          /*1. ans*/  

                while(true){ try
                    {
                    int e = 0;
                    do
                        {
                            Console.WriteLine("Select option from 1, 2 or 3 only");
                            Console.WriteLine(" '1'-To display even number from 0 to given value");
                            Console.WriteLine(" '2'-To display perfect squares");
                            Console.WriteLine(" '3'-To exit");
                            e++;
                        } while (e<1);

                        int aa = int.Parse(Console.ReadLine());

                        if (aa == 1)
                        {
                            Console.WriteLine("Enter an integer number");
                            int a = int.Parse(Console.ReadLine());
                            for (int bb = 0; bb < a; bb += 2)
                            {
                                Console.WriteLine(bb);
                            }

                        }
                        else if (aa == 2)
                        {
                            int ab = 0;
                            while (ab < 1000)
                            {
                                Console.WriteLine("Enter an integer number for getting it's perfect square or press enter for exit");
                                int c = int.Parse(Console.ReadLine());
                                int i = 0;
                                int n = c * c;
                                while (i < 1)
                                {
                                    Console.WriteLine(n);
                                    i++;
                                }

                                ab++;
                            }
                        }
                        else if (aa == 3) { Console.WriteLine("click on cross button to exit"); } 

                        else { Console.WriteLine("enter value from options only"); }

                    }
                    catch (FormatException zz)
                    {
                        Console.WriteLine(zz.Message);
                    }


                }
                           



            /*2. ans*/

         /*
            while (true)
            {

                try
                {


                    int operation = 0;
                    double result = 0;

                    {
                        Console.WriteLine("Type you first number :");
                        string stringFirstNumber = Console.ReadLine();
                        double firstNumber = Convert.ToDouble(stringFirstNumber);

                        Console.WriteLine("Type you second number :");
                        string stringSecondNumber = Console.ReadLine();
                        double secondNumber = Convert.ToDouble(stringSecondNumber);

                        Console.WriteLine("Enter the value '1' for addition, '2' for substraction, '3' for multiplication, '4' for division");
                        int stringOperation = int.Parse(Console.ReadLine());

                        if (stringOperation == 1)
                        {
                            operation = 1;
                        }
                        else if (stringOperation == 2 )
                        {
                            operation = 2;
                        }
                        else if (stringOperation == 3)
                        {
                            operation = 3;
                        }
                        else if (stringOperation == 4)
                        {
                            operation = 4;
                        }
                        else { Console.WriteLine("Enter value from given options only"); }

                        switch (operation)
                        {
                            case 1:
                                {
                                    result = firstNumber + secondNumber;
                                    Console.WriteLine("\nResult of " + firstNumber + " "  +"+ " + secondNumber + " = " + result + ".");
                                    break;
                                }

                            case 2:
                                {
                                    result = firstNumber - secondNumber;
                                    Console.WriteLine("\nResult of " + firstNumber + " " + "- " + secondNumber + " = " + result + ".");
                                    break;
                                }

                            case 3:
                                {
                                    result = firstNumber * secondNumber;
                                    Console.WriteLine("\nResult of " + firstNumber + " " + " *" + secondNumber + " = " + result + ".");
                                    break;
                                }

                            case 4:
                                {
                                    result = firstNumber / secondNumber;
                                    Console.WriteLine("\nResult of " + firstNumber + " " + "/ " + secondNumber + " = " + result + ".");
                                    break;
                                }

                            default: { break; }


                        }
                        

                    }
                }

                catch (FormatException z)
                {
                    Console.WriteLine("Enter valid value");
                }
                Console.WriteLine("press any key to re-calculate");
                Console.ReadLine();
            }       
                  */

        }
    }
}
